
// VC_DemoDlg.h : ͷ�ļ�
//

#pragma once


// CVC_DemoDlg �Ի���
class CVC_DemoDlg : public CDialogEx
{
	// ����
public:
	CVC_DemoDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_VC_DEMO_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��

	HANDLE msdk_handle;

	// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	static void runinThread();
	void begin_check_game();
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedButtonOpen();
	afx_msg void OnBnClickedButtonClose();
	afx_msg void OnBnClickedButtonKeypress();
	afx_msg void OnBnClickedButtonMover();
	afx_msg void OnBnClickedButtonMoveto();
	afx_msg void OnBnClickedButtonGetmousepos();
	afx_msg void OnBnClickedButtonKeypress3();
	int m_intMinute;
	void saveScreen();
	CEdit m_editLog;
	afx_msg void OnBnClickedButtonOpen2();
	CEdit m_editLogInfor;
	afx_msg void OnBnClickedButtonKeypress5();
	afx_msg void OnBnClickedButtonKeypress4();
	afx_msg void OnEnChangeEdit2();
	CListBox m_listWindow;
	CString m_edit_keyword;
	afx_msg void OnBnClickedButtonKeypress6();
	void playerlogin();
	double m_rate;
	afx_msg void OnEnChangeEdit5();
	CEdit m_editRate;
	int m_checkTimes;
	afx_msg void OnEnChangeEdit6();
	afx_msg void OnBnClickedButtonMover2();
	afx_msg void OnEnChangeEdit1();
	afx_msg void OnBnClickedButtonKeypress7();
	void setShowWindowSize(int posX, int posY, int width, int height);
	afx_msg void OnLbnSelchangeList1();
	afx_msg void OnBnClickedButtonGetmousepos2();
	afx_msg void OnBnClickedButtonKeypress8();
	CListBox m_listLog;
	afx_msg void OnEnChangeEdit7();
	int m_screenWidth;
	afx_msg void OnBnClickedButtonOpen3();
	afx_msg void OnLbnSelchangeList2();
	afx_msg void OnBnClickedCheck1();
	BOOL bHuangLong;
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnClose();
	CListBox m_list_time_log;
	afx_msg void OnBnClickedButtonKeyOnScreen();
};
